package com.example.iteratorvisitor;

import java.util.List;

public class Docente extends Persona {
    public Docente(int codigo, String nombres, String direccion, List<String> telefonos) {
        super(codigo, nombres, direccion, telefonos);
    }

    @Override
    public void accept(Visitor visitor) {
        visitor.visitDocente(this);
    }

    public boolean codigoValido() {
        return String.valueOf(codigo).length() <= 4;
    }
}