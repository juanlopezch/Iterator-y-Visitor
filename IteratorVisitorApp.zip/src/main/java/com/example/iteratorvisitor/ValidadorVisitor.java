package com.example.iteratorvisitor;

public class ValidadorVisitor implements Visitor {
    @Override
    public void visitEstudiante(Estudiante estudiante) {
        if (!estudiante.datosCompletos()) {
            System.out.println("Estudiante incompleto: " + estudiante.nombres);
        }
    }

    @Override
    public void visitDocente(Docente docente) {
        if (!docente.datosCompletos()) {
            System.out.println("Docente incompleto: " + docente.nombres);
        } else if (!docente.codigoValido()) {
            System.out.println("Código inválido para docente: " + docente.nombres);
        }
    }
}