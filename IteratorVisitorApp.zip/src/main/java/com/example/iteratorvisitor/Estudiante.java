package com.example.iteratorvisitor;

import java.util.List;

public class Estudiante extends Persona {
    public Estudiante(int codigo, String nombres, String direccion, List<String> telefonos) {
        super(codigo, nombres, direccion, telefonos);
    }

    @Override
    public void accept(Visitor visitor) {
        visitor.visitEstudiante(this);
    }
}