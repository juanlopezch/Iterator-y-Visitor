package com.example.iteratorvisitor;

import java.util.List;

public abstract class Persona {
    protected int codigo;
    protected String nombres;
    protected String direccion;
    protected List<String> telefonos;

    public Persona(int codigo, String nombres, String direccion, List<String> telefonos) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.direccion = direccion;
        this.telefonos = telefonos;
    }

    public abstract void accept(Visitor visitor);

    public boolean datosCompletos() {
        return nombres != null && !nombres.isEmpty() &&
               direccion != null && !direccion.isEmpty() &&
               telefonos != null && !telefonos.isEmpty();
    }

    public int getCodigo() {
        return codigo;
    }
}