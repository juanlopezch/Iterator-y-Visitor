package com.example.iteratorvisitor;

import java.util.Iterator;
import java.util.List;

public class PersonaIterator implements Iterator<Persona> {
    private List<Persona> personas;
    private int index = 0;

    public PersonaIterator(List<Persona> personas) {
        this.personas = personas;
    }

    @Override
    public boolean hasNext() {
        return index < personas.size();
    }

    @Override
    public Persona next() {
        return personas.get(index++);
    }
}