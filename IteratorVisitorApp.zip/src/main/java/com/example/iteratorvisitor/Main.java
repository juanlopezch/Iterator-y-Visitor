package com.example.iteratorvisitor;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Persona> personas = new ArrayList<>();
        personas.add(new Estudiante(101, "Ana Torres", "Calle 123", Arrays.asList("123456789")));
        personas.add(new Docente(2023, "Carlos Pérez", "Av. Central", Arrays.asList("987654321")));
        personas.add(new Docente(99999, "Laura Gómez", "", Arrays.asList(""))); // datos incompletos y código largo

        PersonaIterator iterator = new PersonaIterator(personas);
        ValidadorVisitor visitor = new ValidadorVisitor();

        while (iterator.hasNext()) {
            Persona persona = iterator.next();
            persona.accept(visitor);
        }
    }
}