package com.example.iteratorvisitor;

public interface Visitor {
    void visitEstudiante(Estudiante estudiante);
    void visitDocente(Docente docente);
}